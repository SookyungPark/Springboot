package com.example.boardTest;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {

    BoardUserDTO findById(String userId); // 로그인용
    void insertUser(BoardUserDTO user);   // 회원가입용



}

