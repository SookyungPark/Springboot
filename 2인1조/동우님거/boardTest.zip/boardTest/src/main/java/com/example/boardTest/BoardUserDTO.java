package com.example.boardTest;

import lombok.Data;

@Data
public class BoardUserDTO {
    private String userId;
    private String userPw;
    private String name;


}
